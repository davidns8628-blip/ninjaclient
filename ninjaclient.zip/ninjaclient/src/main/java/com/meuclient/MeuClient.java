package com.meuclient;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.text.Text;

public class MeuClient implements ClientModInitializer {
    public static ModuleManager modules;
    public static boolean openMenu;

    @Override
    public void onInitializeClient() {
        modules = new ModuleManager();
        ClientCommandRegistrationCallback.EVENT.register((d, r) -> d.register(ClientCommandManager.literal("ninja").executes(c -> { openMenu = true; return 1; })));
        ClientTickEvents.END_CLIENT_TICK.register(modules::tick);

        // /toggle fly | /toggle sprint | /toggle fullbright
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommandManager.literal("toggle")
                .then(ClientCommandManager.argument("modulo", StringArgumentType.word())
                    .suggests((ctx, b) -> {
                        modules.modules.forEach(m -> b.suggest(m.name.toLowerCase()));
                        return b.buildFuture();
                    })
                    .executes(ctx -> {
                        String nome = StringArgumentType.getString(ctx, "modulo");
                        Module m = modules.get(nome);
                        if (m == null) {
                            ctx.getSource().sendFeedback(Text.literal("§cModulo nao encontrado: " + nome));
                            return 0;
                        }
                        m.toggle();
                        return 1;
                    }))));
    }
}
