package com.meuclient;

import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

public abstract class Module {
    public final String name;
    public final Category category;
    private boolean enabled;
    protected final MinecraftClient mc = MinecraftClient.getInstance();

    // tecla de atalho que liga/desliga o modulo (opcional)
    private boolean hasToggleKey;
    private int toggleKey;
    private boolean toggleKeyHeld;
    private boolean bindingKey;

    public Module(String name, Category category) {
        this.category = category;
        this.name = name;
    }

    /** Ativa o atalho: apertar a tecla liga/desliga o modulo. Use -1 para comecar sem tecla; mapeie no menu. */
    protected void enableToggleKey(int defaultKey) {
        hasToggleKey = true;
        toggleKey = defaultKey;
    }

    public void setKey(int k) {
        if (!hasToggleKey) return;
        toggleKey = k;
        bindingKey = false;
        toggleKeyHeld = true;
    }

    public static String keyName(int key) {
        if (key < 0) return "--"; // sem tecla
        String name = GLFW.glfwGetKeyName(key, 0);
        String label = name != null ? name.toUpperCase() : "#" + key;
        return label.length() > 4 ? label.substring(0, 4) : label;
    }

    public boolean isEnabled() { return enabled; }

    public void toggle() {
        enabled = !enabled;
        if (enabled) onEnable(); else onDisable();
        if (mc.player != null) {
            mc.player.sendMessage(net.minecraft.text.Text.literal(
                "§7[NinjaClient] §f" + name + (enabled ? " §aON" : " §cOFF")), true);
        }
    }

    /** Texto extra mostrado ao lado do nome no menu (ex.: opcao atual). */
    public String suffix() { return ""; }

    /** Texto do botao de tecla mostrado no menu; null = modulo sem tecla. */
    public String bindLabel() {
        if (!hasToggleKey) return null;
        return bindingKey ? "..." : keyName(toggleKey);
    }

    /** Chamado quando o jogador clica no botao de tecla no menu. */
    public void onBindClick() {
        if (hasToggleKey) bindingKey = true;
    }

    /** Chamado quando o jogador clica com o botao direito no modulo no menu. */
    public void onRightClick() {}

    /**
     * Chamado todo tick, mesmo com o modulo desligado.
     * Aqui: captura a nova tecla e liga/desliga ao apertar o atalho.
     */
    public void onBackgroundTick() {
        if (!hasToggleKey) return;
        long window = mc.getWindow().getHandle();

        if (bindingKey) {
            for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
                if (k == GLFW.GLFW_KEY_RIGHT_ALT || k == GLFW.GLFW_KEY_W || k == GLFW.GLFW_KEY_A || k == GLFW.GLFW_KEY_S || k == GLFW.GLFW_KEY_D || k == GLFW.GLFW_KEY_SPACE || k == GLFW.GLFW_KEY_LEFT_SHIFT) continue; // menu e teclas de andar
                if (GLFW.glfwGetKey(window, k) == GLFW.GLFW_PRESS) {
                    if (k != GLFW.GLFW_KEY_ESCAPE) toggleKey = k;
                    bindingKey = false;
                    toggleKeyHeld = true; // nao conta como aperto
                    return;
                }
            }
            return;
        }

        boolean down = toggleKey >= 0 && mc.currentScreen == null
                && GLFW.glfwGetKey(window, toggleKey) == GLFW.GLFW_PRESS;
        if (down && !toggleKeyHeld) toggle();
        toggleKeyHeld = down;
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
}
