package com.meuclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class NinjaMenuScreen extends Screen {
    // fundo escuro, selecionado = azul escuro
    private static final int HEADER = 0xFF0F1A5C, ROW_BG = 0xF0202024, ROW_HOVER = 0xF02C2C34,
            ROW_ON = 0xFF1B2A8A, ROW_ON_HOVER = 0xFF2438B0, TEXT = 0xFFE6E6E6, TEXT_OFF = 0xFFB4B4BE;
    private static final int COL_W = 120, GAP = 14, HEADER_H = 20, ROW_H = 18, TOP = 40;

    private boolean mouseHeld = true; // evita clique fantasma ao abrir
    private boolean rightHeld = true;

    public NinjaMenuScreen() {
        super(Text.literal("NinjaClient"));
    }

    @Override
    public boolean shouldPause() { return false; }

    private static boolean in(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private List<Module> modulesOf(Category c) {
        List<Module> list = new ArrayList<>();
        for (Module m : MeuClient.modules.modules) if (m.category == c) list.add(m);
        return list;
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        boolean down = GLFW.glfwGetMouseButton(MinecraftClient.getInstance().getWindow().getHandle(),
                GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean click = down && !mouseHeld;
        mouseHeld = down;

        boolean rightDown = GLFW.glfwGetMouseButton(MinecraftClient.getInstance().getWindow().getHandle(),
                GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        boolean rightClick = rightDown && !rightHeld;
        rightHeld = rightDown;

        Category[] cats = Category.values();
        int totalW = cats.length * COL_W + (cats.length - 1) * GAP;
        int x = (this.width - totalW) / 2;

        for (Category c : cats) {
            // cabecalho
            ctx.fill(x, TOP, x + COL_W, TOP + HEADER_H, HEADER);
            ctx.drawText(textRenderer, c.label, x + 6, TOP + 6, 0xFFFFFFFF, false);

            // modulos
            int y = TOP + HEADER_H;
            for (Module m : modulesOf(c)) {
                boolean hov = in(mx, my, x, y, COL_W, ROW_H);
                String bind = m.bindLabel();
                boolean onBind = bind != null && in(mx, my, x + COL_W - 36, y, 36, ROW_H);
                if (hov && click) {
                    if (onBind) m.onBindClick(); else m.toggle();
                }
                if (hov && rightClick) m.onRightClick();

                int bg = m.isEnabled() ? (hov ? ROW_ON_HOVER : ROW_ON) : (hov ? ROW_HOVER : ROW_BG);
                ctx.fill(x, y, x + COL_W, y + ROW_H, bg);
                ctx.drawText(textRenderer, m.name + m.suffix(), x + 6, y + 5, m.isEnabled() ? 0xFFFFFFFF : TEXT_OFF, false);
                if (bind != null) {
                    ctx.fill(x + COL_W - 34, y + 2, x + COL_W - 2, y + ROW_H - 2, onBind ? 0xFF2438B0 : 0xFF0F1A5C);
                    ctx.drawText(textRenderer, bind, x + COL_W - 31, y + 5, 0xFFFFFFFF, false);
                }
                y += ROW_H;
            }
            x += COL_W + GAP;
        }
    }
}
