package com.meuclient;

import com.meuclient.modules.*;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public final List<Module> modules = new ArrayList<>();
    private boolean menuKeyHeld;

    public ModuleManager() {
        modules.add(new KillAura());
        modules.add(new AimAssist());
        modules.add(new TriggerBot());
        modules.add(new AutoClicker());
        modules.add(new AutoMace());
        modules.add(new AutoCrystal());
        modules.add(new AutoLanca());
        modules.add(new Fly());
        modules.add(new Sprint());
        modules.add(new Fullbright());
    }

    public Module get(String name) {
        for (Module m : modules) {
            if (m.name.equalsIgnoreCase(name)) return m;
        }
        return null;
    }

    public void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) return;

        // AltGr = Alt direito (GLFW_KEY_RIGHT_ALT)
        boolean down = GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_ALT) == GLFW.GLFW_PRESS;
        if (down && !menuKeyHeld && mc.currentScreen == null) {
            mc.setScreen(new NinjaMenuScreen());
        }
        menuKeyHeld = down;

        for (Module m : modules) {
            m.onBackgroundTick();
            if (m.isEnabled()) m.onTick();
        }
    }
}
