package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.Module;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;

public class AutoClicker extends Module {
    private int ticks;

    public AutoClicker() {
        super("AutoClicker", Category.COMBAT);
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
    }

    @Override
    public void onTick() {
        if (!mc.options.attackKey.isPressed() || mc.currentScreen != null) return;
        if (++ticks < 2) return; // ~10 cliques por segundo
        ticks = 0;
        if (mc.crosshairTarget instanceof EntityHitResult hit) {
            mc.interactionManager.attackEntity(mc.player, hit.getEntity());
        }
        mc.player.swingHand(Hand.MAIN_HAND);
    }
}
