package com.meuclient.modules;

import com.meuclient.Module;

public class Fly extends Module {
    public Fly() {
        super("Fly", com.meuclient.Category.MOVEMENT);
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
    }

    @Override
    public void onTick() {
        mc.player.getAbilities().allowFlying = true;
        mc.player.getAbilities().flying = true;
    }

    @Override
    public void onDisable() {
        if (mc.player != null && !mc.player.isCreative() && !mc.player.isSpectator()) {
            mc.player.getAbilities().allowFlying = false;
            mc.player.getAbilities().flying = false;
        }
    }
}
