package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.Module;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.registry.Registries;
import org.lwjgl.glfw.GLFW;

/**
 * AutoLanca (Minecraft 1.21.11): lunge swap da lanca com uma tecla.
 *
 * Segurando a tecla: procura o jogador mais proximo (ate 4.5 blocos, visivel),
 * vira para ele e, no MESMO tick, troca para a lanca com Lunge, ataca e volta
 * para a mao vazia. Repete a cada 5 ticks. Ao soltar a tecla, devolve o slot.
 * (Aproveita o bug de troca de atributos MC-28289 do jogo.)
 *
 * Ligue o modulo no menu (clique no nome). Clique no botao da tecla (ao lado do
 * nome), aperte a nova tecla e ela fica mapeada. Esc cancela. Sem tecla padrao.
 */
public class AutoLanca extends Module {
    private static final int COOLDOWN_TICKS = 5;

    private int key = -1; // sem tecla padrao: mapeie no menu
    private boolean binding;

    private boolean active;
    private int originalSlot, parkSlot, timer;

    public AutoLanca() { super("AutoLanca", Category.COMBAT); }

    /** Botao de tecla no menu: mostra a tecla atual; clique para mapear outra. */
    @Override
    public String bindLabel() {
        if (binding) return "...";
        return keyName(key);
    }

    @Override
    public void onBindClick() { binding = true; }

    @Override
    public void onRightClick() {}

    @Override
    public void setKey(int k) { key = k; binding = false; }

    /** Captura a nova tecla mesmo com o modulo desligado. */
    @Override
    public void onBackgroundTick() {
        if (!binding) return;
        long window = mc.getWindow().getHandle();
        for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
            if (k == GLFW.GLFW_KEY_RIGHT_ALT || k == GLFW.GLFW_KEY_W || k == GLFW.GLFW_KEY_A || k == GLFW.GLFW_KEY_S || k == GLFW.GLFW_KEY_D || k == GLFW.GLFW_KEY_SPACE || k == GLFW.GLFW_KEY_LEFT_SHIFT) continue; // menu e teclas de andar
            if (GLFW.glfwGetKey(window, k) == GLFW.GLFW_PRESS) {
                if (k != GLFW.GLFW_KEY_ESCAPE) key = k;
                binding = false;
                return;
            }
        }
    }

    @Override
    public void onDisable() {
        if (active) restore();
    }

    @Override
    public void onTick() {
        boolean held = key >= 0 && !binding && mc.currentScreen == null
                && GLFW.glfwGetKey(mc.getWindow().getHandle(), key) == GLFW.GLFW_PRESS;
        if (!held) {
            if (active) restore();
            return;
        }

        if (!active) {
            active = true;
            originalSlot = mc.player.getInventory().getSelectedSlot();
            parkSlot = findEmptySlot();
            timer = 0;
            if (parkSlot != -1) selectSlot(parkSlot);
        }

        if (timer > 0) { timer--; return; }

        PlayerEntity target = Combat.nearestPlayer(mc, 4.5, true);
        if (target == null) return;
        int spear = findSpear();
        if (spear == -1) return;

        Combat.aimAt(mc, target, 180f);

        // tudo no mesmo tick: lanca -> ataque -> mao vazia
        selectSlot(spear);
        Combat.attack(mc, target);
        selectSlot(parkSlot != -1 ? parkSlot : originalSlot);
        timer = COOLDOWN_TICKS;
    }

    private void restore() {
        selectSlot(originalSlot);
        active = false;
    }

    private void selectSlot(int slot) {
        mc.player.getInventory().setSelectedSlot(slot);
        if (mc.getNetworkHandler() != null) {
            mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slot));
        }
    }

    private int findEmptySlot() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isEmpty()) return i;
        }
        return -1;
    }

    /** Prefere lanca com Lunge; se nao houver, usa qualquer lanca da hotbar. */
    private int findSpear() {
        int any = -1;
        for (int i = 0; i < 9; i++) {
            var stack = mc.player.getInventory().getStack(i);
            if (stack.isEmpty()) continue;
            if (!Registries.ITEM.getId(stack.getItem()).getPath().endsWith("_spear")) continue;
            boolean lunge = stack.getEnchantments().getEnchantments().stream()
                    .anyMatch(e -> e.getIdAsString().equals("minecraft:lunge"));
            if (lunge) return i;
            if (any == -1) any = i;
        }
        return any;
    }
}
