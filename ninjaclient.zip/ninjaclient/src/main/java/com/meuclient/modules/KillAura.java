package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.Module;
import net.minecraft.entity.player.PlayerEntity;

public class KillAura extends Module {
    // barra de cooldown minima para atacar: 0.90 = 90% (use 0.80 para 80%)
    private static final float MIN_COOLDOWN = 0.90f;

    public KillAura() {
        super("KillAura", Category.COMBAT);
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
    }

    @Override
    public void onTick() {
        PlayerEntity target = Combat.nearestPlayer(mc, 3.5, true); // true = so ataca quem esta visivel, nunca atras de blocos
        if (target == null || !Combat.cooldownReady(mc, MIN_COOLDOWN)) return;
        Combat.aimAt(mc, target, 180f);
        Combat.attack(mc, target);
    }
}
