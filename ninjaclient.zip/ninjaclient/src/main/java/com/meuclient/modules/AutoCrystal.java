package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.Module;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Crystal PvP automatico (ciclo: colocar -> detonar):
 *  1. Acha o jogador mais proximo (ate 8 blocos).
 *  2. Detona cristais perto dele (longe de voce, para nao tomar o dano).
 *  3. Coloca cristal na obsidiana/bedrock mais proxima dele, ao alcance.
 */
public class AutoCrystal extends Module {
    private static final double REACH = 4.5;       // alcance para colocar/bater
    private static final double MIN_SELF_DIST = 2.5; // distancia minima do cristal ate voce
    private static final double MIN_HEALTH = 6.0;  // com menos vida que isso, nao age

    // atrasos em ticks (valores tipicos de hack clients: colocar 0-1, bater 1-2)
    private static final int PLACE_DELAY_MIN = 0, PLACE_DELAY_MAX = 1;
    private static final int BREAK_DELAY_MIN = 1, BREAK_DELAY_MAX = 2;

    private static final int PAUSE_AFTER_KILL = 20; // 1 segundo (20 ticks)

    private int killPause;
    private PlayerEntity lastTarget;
    private int placeTimer;
    private int breakTimer;
    private final java.util.Random random = new java.util.Random();

    public AutoCrystal() {
        super("AutoCrystal", Category.COMBAT);
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
    }

    @Override
    public void onDisable() {
        lastTarget = null;
        killPause = 0;
    }

    @Override
    public void onTick() {
        if (mc.player.getHealth() + mc.player.getAbsorptionAmount() < MIN_HEALTH) return;

        // se o alvo anterior morreu, pausa um tempo antes de voltar a agir
        if (lastTarget != null && (!lastTarget.isAlive() || lastTarget.isRemoved())) {
            killPause = PAUSE_AFTER_KILL;
            lastTarget = null;
        }
        if (killPause > 0) {
            killPause--;
            return;
        }

        PlayerEntity target = Combat.nearestPlayer(mc, 8.0);
        if (target == null) return;
        lastTarget = target;

        // timers independentes, com atraso aleatorio para parecer natural
        if (breakTimer > 0) breakTimer--;
        if (placeTimer > 0) placeTimer--;

        // 1) detonar cristal proximo do alvo
        if (breakTimer == 0) {
            for (Entity e : mc.world.getEntities()) {
                if (!(e instanceof EndCrystalEntity crystal) || !crystal.isAlive()) continue;
                if (crystal.distanceTo(target) > 5.0) continue;
                if (mc.player.distanceTo(crystal) < MIN_SELF_DIST || mc.player.distanceTo(crystal) > REACH) continue;
                Combat.attack(mc, crystal);
                breakTimer = randomBetween(BREAK_DELAY_MIN, BREAK_DELAY_MAX);
                break; // um cristal por vez
            }
        }

        // 2) colocar novo cristal
        if (placeTimer > 0) return;

        int slot = findCrystalSlot();
        if (slot == -1) return;

        BlockPos base = findBase(target);
        if (base == null) return;

        if (mc.player.getInventory().getSelectedSlot() != slot) {
            mc.player.getInventory().setSelectedSlot(slot);
        }
        BlockHitResult hit = new BlockHitResult(Vec3d.ofCenter(base).add(0, 0.5, 0), Direction.UP, base, false);
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
        mc.player.swingHand(Hand.MAIN_HAND);
        placeTimer = randomBetween(PLACE_DELAY_MIN, PLACE_DELAY_MAX);
    }

    private int randomBetween(int min, int max) {
        return min + random.nextInt(max - min + 1);
    }

    private int findCrystalSlot() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isOf(Items.END_CRYSTAL)) return i;
        }
        return -1;
    }

    /** Melhor obsidiana/bedrock perto do alvo: espaco livre em cima e longe de voce. */
    private BlockPos findBase(PlayerEntity target) {
        BlockPos t = target.getBlockPos();
        Vec3d eye = mc.player.getEyePos();
        BlockPos best = null;
        double bestScore = Double.MAX_VALUE;

        for (int dx = -3; dx <= 3; dx++) {
            for (int dy = -2; dy <= 0; dy++) {
                for (int dz = -3; dz <= 3; dz++) {
                    BlockPos p = t.add(dx, dy, dz);
                    var state = mc.world.getBlockState(p);
                    if (!state.isOf(Blocks.OBSIDIAN) && !state.isOf(Blocks.BEDROCK)) continue;
                    if (!mc.world.getBlockState(p.up()).isAir() || !mc.world.getBlockState(p.up(2)).isAir()) continue;
                    if (!mc.world.getOtherEntities(null, new Box(p.up())).isEmpty()) continue;

                    Vec3d center = Vec3d.ofCenter(p);
                    if (eye.distanceTo(center) > REACH) continue;
                    if (mc.player.getEntityPos().distanceTo(center.add(0, 1, 0)) < MIN_SELF_DIST) continue;

                    // quanto mais perto do alvo (e mais baixo), melhor o dano
                    double score = target.getEntityPos().distanceTo(center.add(0, 1, 0)) + (t.getY() - p.getY()) * 0.1;
                    if (score < bestScore) {
                        bestScore = score;
                        best = p;
                    }
                }
            }
        }
        return best;
    }
}
