package com.meuclient.modules;

import com.meuclient.Category;
import com.meuclient.Module;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;

/**
 * Caindo de uma altura (fallDistance > 1.5, o minimo do smash no vanilla):
 * troca para a clava da hotbar, mira no jogador mais proximo e ataca.
 * Usa so acoes normais (troca de slot, mira e ataque), sem fingir posicao.
 */
public class AutoMace extends Module {
    public AutoMace() {
        super("AutoMace", Category.COMBAT);
        enableToggleKey(-1); // sem tecla padrao: mapeie no menu
    }

    @Override
    public void onTick() {
        if (mc.player.isOnGround() || mc.player.fallDistance <= 1.5) return;

        PlayerEntity target = Combat.nearestPlayer(mc, 3.0);
        if (target == null) return;

        // troca para a clava se nao estiver com ela na mao
        if (!mc.player.getMainHandStack().isOf(Items.MACE)) {
            for (int i = 0; i < 9; i++) {
                if (mc.player.getInventory().getStack(i).isOf(Items.MACE)) {
                    mc.player.getInventory().setSelectedSlot(i);
                    return; // ataca no proximo tick, ja com a clava
                }
            }
            return; // sem clava na hotbar
        }

        Combat.aimAt(mc, target, 180f);
        Combat.attack(mc, target);
    }
}
